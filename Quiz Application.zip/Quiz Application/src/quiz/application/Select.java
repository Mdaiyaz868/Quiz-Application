package quiz.application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Select extends JFrame implements ActionListener{

    String name;
    JButton math,java,english,dbms,aptitude,back;
    
    Select(String name) {
        this.name = name;
        getContentPane().setBackground(new Color(230, 255, 247));
        setLayout(null);
        
        JLabel heading = new JLabel("Select  " + name + "");
        heading.setBounds(50, 20, 700, 30);
        heading.setFont(new Font("Comic Sans MS", Font.BOLD, 28));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);
        
        back = new JButton("Back");
        back.setBounds(300, 250, 100, 30);
        back.setBackground(new Color(30, 144, 254));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);
     
         JLabel teams = new JLabel();
        teams.setBounds(50, 350, 700, 350);
        teams.setFont(new Font("Tahoma", Font.BOLD, 20));
        teams.setText(
            "<html>"+ 
                "Team Name:" + " " +
                "Md Aiyaz, Md Aquib, Anisha Mehta, Utkarsh Bansal" + "<br><br>" +
            "<html>"
        );
       add(teams);
        
        math = new JButton("Maths");
        math.setBounds(400, 150, 100, 30);
        math.setBackground(new Color(30, 144, 254));
        math.setForeground(Color.WHITE);
        math.addActionListener(this);
        add(math);
        
        java = new JButton("Java");
        java.setBounds(400, 100, 100, 30);
        java.setBackground(new Color(30, 144, 254));
        java.setForeground(Color.WHITE);
        java.addActionListener(this);
        add(java);
        
        english = new JButton("Verbal Ability");
        english.setBounds(175, 200, 100, 30);
        english.setBackground(new Color(30, 144, 254));
        english.setForeground(Color.WHITE);
        english.addActionListener(this);
        add(english);
        
        dbms = new JButton("DBMS");
        dbms.setBounds(175, 150, 100, 30);
        dbms.setBackground(new Color(30, 144, 254));
        dbms.setForeground(Color.WHITE);
        dbms.addActionListener(this);
        add(dbms);
       
        aptitude = new JButton("Reasoning");
        aptitude.setBounds(175, 100, 100, 30);
        aptitude.setBackground(new Color(30, 144, 254));
        aptitude.setForeground(Color.WHITE);
        aptitude.addActionListener(this);
        add(aptitude);
       
        setSize(800, 650);
        setLocation(350, 100);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == math) {
            setVisible(false);
            new Math(name).setVisible(true);
        }else if(ae.getSource() == aptitude) {
            setVisible(false);
            new Aptitude(name).setVisible(true);
        }else if(ae.getSource() == english) {
            setVisible(false);
            new English(name).setVisible(true);
        }else if(ae.getSource() == java) {
            setVisible(false);
            new Java(name).setVisible(true);
        }else if(ae.getSource() == dbms) {
            setVisible(false);
            new DBMS(name).setVisible(true);
        }
        else {
            setVisible(false);
            new Login();
        }
    }
    
    public static void main(String[] args) {
        new Select("Quiz");
    }
}
