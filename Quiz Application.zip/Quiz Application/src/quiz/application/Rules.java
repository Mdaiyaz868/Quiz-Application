package quiz.application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Rules extends JFrame implements ActionListener{

    String name;
    JButton next, back;
    
    Rules(String name) {
        this.name = name;
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel heading = new JLabel( " Brain Trivia welcomes you " + name );
        heading.setBounds(50, 20, 700, 30);
        heading.setFont(new Font("clarendon-fortune-bold", Font.BOLD, 28));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);
        
        JLabel rules = new JLabel();
        rules.setBounds(20, 90, 700, 350);
        rules.setFont(new Font("Tahoma", Font.PLAIN, 16));
        rules.setText(
            "<html>"+ 
                "1. Total 10 Questions are asked." + "<br><br>" +
                "2. Each Question carries Two Marks." + "<br><br>" +
                "3. No Negative Marking." + "<br><br>" +
                "4. Select your answer and submit." + "<br><br>" +
                "5. Total time 3 Minutes" + "<br><br>" +
                "6. Time 15 Seconds for each question" + "<br><br>" +
            "<html>"
        );
        add(rules);
        
        back = new JButton("Back");
        back.setBounds(250, 400, 100, 30);
        back.setBackground(new Color(30, 144, 254));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);
        
        next = new JButton("Next");
        next.setBounds(400, 400, 100, 30);
        next.setBackground(new Color(30, 144, 254));
        next.setForeground(Color.WHITE);
        next.addActionListener(this);
        add(next);
        
         JLabel teams = new JLabel();
        teams.setBounds(50, 350, 700, 350);
        teams.setFont(new Font("Tahoma", Font.BOLD, 20));
        teams.setText(
            "<html>"+ 
                "Team Name:" + " " +
                "Md Aiyaz, Md Aquib, Anisha Mehta, Utkarsh Bansal" + "<br><br>" +
            "<html>"
        );
       add(teams);
        
        setSize(800, 650);
        setLocation(350, 100);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == next) {
            setVisible(false);
            new Select(name).setVisible(true);
        } else {
            setVisible(false);
            new Login();
        }
    }
    
    public static void main(String[] args) {
        new Rules("User");
    }
}
